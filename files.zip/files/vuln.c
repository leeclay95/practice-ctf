#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void win() {
    setuid(0);
    setgid(0);
    char *args[] = {"/bin/sh", "-i", NULL};
    execve("/bin/sh", args, NULL);
}

void vuln(char *input) {
    char buffer[64];
    strcpy(buffer, input);
    printf("Processing: %s\n", buffer);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        printf("System checker failed.\n");
        return 1;
    }
    
    vuln(argv[1]);
    printf("Check completed.\n");
    return 0;
}
