#!/usr/bin/env python3
import sqlite3
import base64
from urllib.parse import unquote
from flask import Flask, request, jsonify, render_template_string, session
import os

app = Flask(__name__)
app.secret_key = 'ctf_secret_key_12345'

def init_db():
    conn = sqlite3.connect('ctf_database.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE,
            password TEXT,
            role TEXT
        )
    ''')
    
    cursor.execute('''
        INSERT OR REPLACE INTO users (id, username, password, role) 
        VALUES (1, 'able', 'C@nt_Gu3$$_m3', 'user')
    ''')
    
    conn.commit()
    conn.close()

LOGIN_PAGE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Secure Login Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            width: 400px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
        }
        input[type="text"]:focus, input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #5568d3;
        }
        .test-btn {
            background: #48bb78;
        }
        .test-btn:hover {
            background: #38a169;
        }
        .message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        .error {
            background: #fed7d7;
            color: #c53030;
        }
        .success {
            background: #c6f6d5;
            color: #22543d;
        }
        .hint {
            margin-top: 20px;
            font-size: 12px;
            color: #999;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 Secure Access Portal</h1>
        <p class="subtitle">Can you find the credentials to get into the back in?</p>
        
        <form id="loginForm" method="POST" action="/login">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="username" id="username" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <button type="submit">Login</button>
            <button type="button" class="test-btn" onclick="testConnection()">Test Connection</button>
        </form>
        
        {% if message %}
        <div class="message {{ message_type }}">{{ message }}</div>
        {% endif %}
        
        <div class="hint">Hint: Sometimes the best way in is through the back door... 🔍</div>
    </div>
    
    <script>
        function testConnection() {
            fetch('/test-connection', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({})
            })
            .then(response => response.json())
            .then(data => {
                alert('Connection test completed');
            });
        }
    </script>
</body>
</html>
'''

SUCCESS_PAGE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Login Success</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 {
            color: #333;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }
        .welcome {
            background: #c6f6d5;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            color: #22543d;
        }
        .info {
            background: #ebf8ff;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            color: #2c5282;
        }
        button {
            padding: 10px 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }
        button:hover {
            background: #5568d3;
        }
        code {
            background: #2d3748;
            color: #48bb78;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎯 Login Successful</h1>
        
        <div class="welcome">
            <strong>Welcome!</strong> You have successfully authenticated as {{ username }}.
        </div>
        
        <div class="info">
            <h3>📊 Next Steps</h3>
            <p>Now that you have credentials, SSH to the server to continue:</p>
            <p><code>ssh {{ username }}@localhost -p 2222</code></p>
            <p>Password: <code>C@nt_Gu3$$_m3</code></p>
        </div>
        
        <button onclick="location.href='/logout'">Logout</button>
    </div>
</body>
</html>
'''

@app.route('/')
def index():
    if 'logged_in' in session:
        return render_template_string(SUCCESS_PAGE, username=session['username'])
    return render_template_string(LOGIN_PAGE)

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    conn = sqlite3.connect('ctf_database.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT username, password, role FROM users WHERE username = ? AND password = ?', 
                   (username, password))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        session['logged_in'] = True
        session['username'] = username
        return render_template_string(SUCCESS_PAGE, username=username)
    else:
        return render_template_string(LOGIN_PAGE, 
                                       message="Invalid credentials!", 
                                       message_type="error")

@app.route('/test-connection', methods=['POST'])
def test_connection():
    query_param = None
    
    if request.is_json:
        query_param = request.json.get('query')
    
    if not query_param:
        query_param = request.form.get('query')
    
    if not query_param:
        query_param = request.headers.get('X-SQL-Query')
    
    if query_param:
        try:
            decoded_query = base64.b64decode(unquote(query_param)).decode('utf-8')
            
            conn = sqlite3.connect('ctf_database.db')
            cursor = conn.cursor()
            
            cursor.execute(decoded_query)
            results = cursor.fetchall()
            conn.close()
            
            return jsonify({
                'status': 'success',
                'message': 'Query executed',
                'results': results
            })
        except Exception as e:
            return jsonify({
                'status': 'error',
                'message': f'Query error: {str(e)}'
            })
    
    return jsonify({
        'status': 'ok',
        'message': 'Connection test successful'
    })

@app.route('/logout')
def logout():
    session.clear()
    return render_template_string(LOGIN_PAGE, 
                                   message="Logged out successfully", 
                                   message_type="success")

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=9006, debug=False)
