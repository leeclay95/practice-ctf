#!/bin/bash

/usr/sbin/sshd -D -p 2222 &

su - able -c "cd /opt/webapp && python3 app.py" &

tail -f /dev/null
