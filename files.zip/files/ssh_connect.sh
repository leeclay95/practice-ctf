#!/bin/bash

read -p "Enter target IP address: " TARGET_IP

SSH_USER="ben"
SSH_PASS="B3n_S3cur3_P@ss2024"
SSH_PORT="2223"

echo "Connecting to $TARGET_IP:$SSH_PORT as $SSH_USER..."
sshpass -p "$SSH_PASS" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -p $SSH_PORT $SSH_USER@$TARGET_IP "ls -la"

if [ $? -ne 0 ]; then
    echo "Connection failed."
fi
